CREATE DATABASE IF NOT EXISTS tododb;
USE tododb;
CREATE TABLE todo (
    id int,
    task VARCHAR(255) NOT NULL,
    completed BOOLEAN DEFAULT FALSE
);
select * from todo;


