package ToDo.List.ToDo.List.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@Table(name = "todo")
public class ToDo {
    @Id
    private int id;
    @Column(name="task")
    private String task;
    @Column(name="completed")
    private boolean completed;
}
