package ToDo.List.ToDo.List.Service;

import ToDo.List.ToDo.List.Dto.OpenAIRequest;
import ToDo.List.ToDo.List.Dto.OpenAIResponse;
import ToDo.List.ToDo.List.Entity.ToDo;
import ToDo.List.ToDo.List.Repository.TodoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class SummaryService {

    private final TodoRepository todoRepository;
    private final RestTemplate restTemplate = new RestTemplate();

    @Retryable(
            value = { HttpClientErrorException.TooManyRequests.class },
            maxAttempts = 3,
            backoff = @org.springframework.retry.annotation.Backoff(delay = 2000)
    )
    public String callOpenAI(String requestBody) {
        String url = "https://api.openai.com/v1/chat/completions";
        // Set headers and body as needed
        return restTemplate.postForObject(url, requestBody, String.class);
    }

    @Value("${spring.ai.openai.api-key}")
    private String openAiKey;

    @Value("${slack.webhook.url}")
    private String slackWebhook;

    public String generateSummaryAndSend() {
        List<ToDo> todos = todoRepository.findAll();

        if (todos == null || todos.isEmpty()) {
            return "No todos available to summarize.";
        }

        String prompt = "Summarize the following todo list in a friendly way:\n" +
                todos.stream()
                        .map(ToDo::getTask)
                        .filter(task -> task != null)
                        .collect(Collectors.joining(","));

        OpenAIRequest request = new OpenAIRequest(
                "gpt-3.5-turbo",
                List.of(new OpenAIRequest.Message("user", prompt))
        );

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(openAiKey);

        HttpEntity<OpenAIRequest> entity = new HttpEntity<>(request, headers);
        ResponseEntity<OpenAIResponse> response = restTemplate.postForEntity(
                "https://api.openai.com/v1/chat/completions",
                entity,
                OpenAIResponse.class
        );

        String summary = response.getBody().getChoices().get(0).getMessage().getContent();

        sendToSlack(summary);
        return summary;
    }

    private void sendToSlack(String summary) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        String body = "{\"text\": \"" + summary.replace("\"", "\\\"") + "\"}";

        HttpEntity<String> request = new HttpEntity<>(body, headers);
        restTemplate.postForEntity(slackWebhook, request, String.class);
    }
    public void generateSummaryAndSend(String prompt) {
        String url = "https://api.openai.com/v1/chat/completions";
        RestTemplate restTemplate = new RestTemplate();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth("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");

        String requestBody = "{ \"model\": \"gpt-3.5-turbo\", \"messages\": [{\"role\":\"user\",\"content\":\"" + prompt + "\"}] }";
        HttpEntity<String> entity = new HttpEntity<>(requestBody, headers);

        try {
            ResponseEntity<String> response = restTemplate.postForEntity(url, entity, String.class);
            System.out.println("OpenAI response: " + response.getBody());
        } catch (HttpClientErrorException.TooManyRequests e) {
            System.err.println("Rate limit exceeded: " + e.getMessage());
        } catch (HttpClientErrorException e) {
            System.err.println("Client error: " + e.getStatusCode() + " - " + e.getResponseBodyAsString());
        } catch (Exception e) {
            System.err.println("Unexpected error: " + e.getMessage());
        }
    }

}
