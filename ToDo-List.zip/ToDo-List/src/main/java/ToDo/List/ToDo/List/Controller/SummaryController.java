package ToDo.List.ToDo.List.Controller;

import ToDo.List.ToDo.List.Service.SummaryService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/todos")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class SummaryController {

    private final SummaryService summaryService;

    @PostMapping("/summarize")
    public ResponseEntity<String> summarizeTodos() {
        String summary = summaryService.generateSummaryAndSend();
        return ResponseEntity.ok(summary);
    }
}
