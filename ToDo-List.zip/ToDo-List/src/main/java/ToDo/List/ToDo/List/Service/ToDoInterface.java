package ToDo.List.ToDo.List.Service;


import ToDo.List.ToDo.List.Entity.ToDo;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ToDoInterface {

    ToDo addToDo(ToDo toDo);
    List<ToDo> getAllTodos();
    ToDo addTodo(ToDo todo);
    void deleteTodo(int id);
}
