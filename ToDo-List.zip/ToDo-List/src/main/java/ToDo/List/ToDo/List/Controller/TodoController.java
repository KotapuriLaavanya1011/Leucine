package ToDo.List.ToDo.List.Controller;

import ToDo.List.ToDo.List.Entity.ToDo;
import ToDo.List.ToDo.List.Service.TodoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/todos")
@CrossOrigin(origins = "*")
public class TodoController {
    @Autowired
    private TodoService todoService;
    @PostMapping("/addToDo")
    public ResponseEntity<String> addFood(@RequestBody ToDo toDo ){
        todoService.addToDo(toDo);

        return ResponseEntity.ok("ToDo-List added Successfully");

    }
    @GetMapping("/getAllTodos")
    public List<ToDo> getAllTodos() {
        return todoService.getAllTodos();
    }
    @PostMapping
    public ToDo addTodo(@RequestBody ToDo todo) {
        return todoService.addTodo(todo);
    }
    @DeleteMapping("/{id}")
    public void deleteTodo(@PathVariable int id) {
        todoService.deleteTodo(id);
    }
}
