package ToDo.List.ToDo.List.Service;

import ToDo.List.ToDo.List.Entity.ToDo;
import ToDo.List.ToDo.List.Repository.TodoRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TodoService implements ToDoInterface{

    @Autowired
    private TodoRepository todoRepository;

    @Override
    public ToDo addToDo(ToDo toDo) {
        return todoRepository.save(toDo);
    }

    public List<ToDo> getAllTodos() {
        return todoRepository.findAll();
    }

    public ToDo addTodo(ToDo todo) {
        return todoRepository.save(todo);
    }

    public void deleteTodo(int id) {
        todoRepository.deleteById(id);
    }
}
