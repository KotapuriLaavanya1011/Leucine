package ToDo.List.ToDo.List.Repository;



import ToDo.List.ToDo.List.Entity.ToDo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TodoRepository extends JpaRepository<ToDo, Integer> {
}

